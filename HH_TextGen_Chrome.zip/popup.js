const GATEWAY = 'https://llmgtw.hhdev.ru/proxy/anthropic/v1/messages';
let busy = false;

// --- SVG Icons ---
const SVG_CLIPBOARD = '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M16 4h2a2 2 0 012 2v14a2 2 0 01-2 2H6a2 2 0 01-2-2V6a2 2 0 012-2h2"/><rect x="8" y="2" width="8" height="4" rx="1"/></svg>';
const SVG_CHECK = '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>';

// --- Ad Text system prompt ---
const AD_SYSTEM_PROMPT = `Ты опытный копирайтер, специализирующийся на HR-рекламе и вакансиях. Твоя задача — создавать эффективные рекламные тексты для размещения на различных рекламных площадках.

Стили написания:
- Креативный — яркий, эмоциональный язык. Метафоры и образные выражения. Яркие заголовки. Сильный призыв к действию.
- Формальный — строгий деловой стиль. Четкие информативные заголовки. Корректный призыв к действию. Фокус на фактах.
- Сбалансированный — эффективный и лаконичный. Короткие цепляющие заголовки. Призыв к действию без кликбейта.

Базовые правила:
1. Текст ТОЛЬКО на русском языке
2. Строго соблюдай лимиты символов для каждой рекламной системы
3. Каждый текст содержит призыв к действию
4. Без кликбейта и манипуляций
5. Фокус на выгодах для соискателя

Рекламные системы и лимиты:
VK:
- vk_universal: заголовок 3–40 символов, текст 3–220 символов
- vk_site: заголовок 3–25 символов, текст 3–90 символов
- vk_lead: заголовок 3–60 символов, текст 3–220 символов
- vk_carousel: заголовок 3–40 символов, текст 3–47 символов

Яндекс.Директ:
- yandex_search: заголовок 1–56 символов, подзаголовок 1–30 символов, текст 1–81 символов
- yandex_rsya: заголовок 1–56 символов, текст 1–81 символов

Telegram:
- telegram_seeds: заголовок 1–56 символов, текст 1–764 символов. Используй переносы строк, 1-2 ключевых фразы жирным (**текст**), 1-2 эмодзи. Рекомендуемый объём текста: 450-500 символов.
- tgads: текст 1–160 символов. Добавь 1 эмодзи.

Формат ответа — строго JSON без markdown-обёртки:
{"texts":[{"system":"точный_id_системы","headline":"заголовок","subheadline":"подзаголовок (только для yandex_search)","text":"основной текст"}]}

В поле system — только точный ID (vk_universal, vk_site, vk_lead, vk_carousel, yandex_search, yandex_rsya, telegram_seeds, tgads). Генерируй по одному блоку для каждой запрошенной системы.`;

// Platform metadata
const PLATFORMS = {
    vk_universal:   { label: 'VK Универсальная', headline: [3, 40], text: [3, 220] },
    vk_site:        { label: 'VK Сайт', headline: [3, 25], text: [3, 90] },
    vk_lead:        { label: 'VK Лид-формы', headline: [3, 60], text: [3, 220] },
    vk_carousel:    { label: 'VK Карусель', headline: [3, 40], text: [3, 47] },
    yandex_search:  { label: 'Яндекс Поиск', headline: [1, 56], subheadline: [1, 30], text: [1, 81] },
    yandex_rsya:    { label: 'Яндекс РСЯ', headline: [1, 56], text: [1, 81] },
    telegram_seeds: { label: 'Telegram Посевы', headline: [1, 56], text: [1, 764] },
    tgads:          { label: 'Telegram Ads', text: [1, 160] },
};

const PLATFORM_GROUP = {
    vk_universal: 'vk', vk_site: 'vk', vk_lead: 'vk', vk_carousel: 'vk',
    yandex_search: 'yandex', yandex_rsya: 'yandex',
    telegram_seeds: 'tg', tgads: 'tg',
};

const STYLE_LABELS = { creative: 'Креативный', balanced: 'Сбалансированный', formal: 'Формальный' };

// --- DOM ---
const tokenInput = document.getElementById('apiToken');
const settingsBtn = document.getElementById('settingsBtn');
const settingsPanel = document.getElementById('sp');
const generateBtn = document.getElementById('generateBtn');
const adDescription = document.getElementById('adDescription');
const adResults = document.getElementById('adResults');
const selectedCountEl = document.getElementById('selectedCount');
const styleIndicator = document.querySelector('.style-indicator');
const styleSelector = document.getElementById('styleSelector');

let adStyle = 'balanced';
let lastResults = null;

// ========================
// Style indicator
// ========================

function positionIndicator(indicator, activeEl) {
    if (!indicator || !activeEl) return;
    indicator.style.left = activeEl.offsetLeft + 'px';
    indicator.style.width = activeEl.offsetWidth + 'px';
}

function initIndicators() {
    const checkedRadio = styleSelector.querySelector('input:checked');
    if (checkedRadio) {
        positionIndicator(styleIndicator, checkedRadio.nextElementSibling);
    }
    requestAnimationFrame(() => {
        requestAnimationFrame(() => {
            styleIndicator.classList.add('ready');
        });
    });
}

// ========================
// Load/save settings
// ========================

chrome.storage.local.get(['hh_token', 'hh_model', 'ad_platforms', 'ad_style', 'ad_description', 'ad_results'], (d) => {
    if (d.hh_token) tokenInput.value = d.hh_token;
    if (d.hh_model) document.getElementById('model').value = d.hh_model;
    if (d.ad_style) {
        adStyle = d.ad_style;
        const radio = document.getElementById('style-' + adStyle);
        if (radio) radio.checked = true;
    }
    if (d.ad_platforms && Array.isArray(d.ad_platforms)) {
        document.querySelectorAll('.cb-pill input').forEach(cb => {
            cb.checked = d.ad_platforms.includes(cb.value);
            cb.closest('.cb-pill').classList.toggle('checked', cb.checked);
        });
    }
    if (d.ad_description) adDescription.value = d.ad_description;
    if (d.ad_results && d.ad_results.texts && d.ad_results.texts.length) {
        renderAdCards(d.ad_results.texts, d.ad_results.meta);
    }
    updateSelectedCount();
    initIndicators();
});

tokenInput.addEventListener('input', () => {
    chrome.storage.local.set({ hh_token: tokenInput.value });
    const b = document.getElementById('ts');
    b.style.display = 'inline';
    setTimeout(() => b.style.display = 'none', 2000);
});
document.getElementById('model').addEventListener('change', (e) => {
    chrome.storage.local.set({ hh_model: e.target.value });
});
adDescription.addEventListener('input', () => {
    chrome.storage.local.set({ ad_description: adDescription.value });
});

// ========================
// Settings
// ========================

settingsBtn.addEventListener('click', () => settingsPanel.classList.toggle('open'));

// ========================
// Pill checkboxes
// ========================

document.querySelectorAll('.cb-pill input').forEach(cb => {
    cb.addEventListener('change', () => {
        cb.closest('.cb-pill').classList.toggle('checked', cb.checked);
        updateSelectedCount();
        saveAdPrefs();
    });
});

function updateSelectedCount() {
    const count = getSelectedPlatforms().length;
    selectedCountEl.textContent = 'Выбрано: ' + count;
    selectedCountEl.classList.toggle('zero', count === 0);
    selectedCountEl.classList.toggle('has', count > 0);
}

function getSelectedPlatforms() {
    return Array.from(document.querySelectorAll('.cb-pill input:checked')).map(cb => cb.value);
}

// ========================
// Style selector
// ========================

styleSelector.querySelectorAll('input[type="radio"]').forEach(radio => {
    radio.addEventListener('change', () => {
        adStyle = radio.value;
        positionIndicator(styleIndicator, radio.nextElementSibling);
        saveAdPrefs();
    });
});

function saveAdPrefs() {
    chrome.storage.local.set({
        ad_platforms: getSelectedPlatforms(),
        ad_style: adStyle,
    });
}

// ========================
// Skeleton loading
// ========================

function showSkeletons(count) {
    let html = '';
    for (let i = 0; i < count; i++) {
        html += '<div class="skeleton-card" style="animation:cardIn 0.25s ease-out both;animation-delay:' + (i * 60) + 'ms">';
        for (let j = 0; j < 5; j++) html += '<div class="skeleton-line"></div>';
        html += '</div>';
    }
    return html;
}

// ========================
// Generate
// ========================

generateBtn.addEventListener('click', generateAdTexts);

async function generateAdTexts() {
    if (busy) return;
    const token = tokenInput.value.trim();
    if (!token) {
        settingsPanel.classList.add('open');
        tokenInput.focus();
        return;
    }

    const platforms = getSelectedPlatforms();
    if (platforms.length === 0) {
        adResults.innerHTML = '<div class="ad-error">Выберите хотя бы одну площадку</div>';
        return;
    }

    const description = adDescription.value.trim();
    if (!description) {
        adDescription.focus();
        return;
    }

    generateBtn.disabled = true;
    generateBtn.classList.add('loading');
    busy = true;
    adResults.innerHTML = showSkeletons(platforms.length);

    const styleName = STYLE_LABELS[adStyle] || adStyle;

    const userMessage = `Сгенерируй рекламные тексты для следующих площадок: ${platforms.join(', ')}

Стиль: ${styleName}

Описание вакансии / контекст:
${description}`;

    try {
        const t0 = performance.now();
        const resp = await fetch(GATEWAY, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'x-api-key': token,
                'anthropic-version': '2023-06-01',
            },
            body: JSON.stringify({
                model: document.getElementById('model').value,
                max_tokens: parseInt(document.getElementById('maxTokens').value) || 4096,
                system: AD_SYSTEM_PROMPT,
                messages: [{ role: 'user', content: userMessage }],
            }),
        });

        const elapsed = ((performance.now() - t0) / 1000).toFixed(1);

        if (!resp.ok) {
            const t = await resp.text();
            throw new Error('HTTP ' + resp.status + ': ' + t.substring(0, 200));
        }

        const data = await resp.json();
        const rawText = data.content?.[0]?.text || '';
        const usage = data.usage || {};
        const meta = data.model + ' \u00b7 ' + usage.input_tokens + '\u2192' + usage.output_tokens + ' tok \u00b7 ' + elapsed + 's';

        let parsed;
        try {
            const jsonStr = rawText.replace(/^```json?\s*/i, '').replace(/\s*```\s*$/, '').trim();
            parsed = JSON.parse(jsonStr);
        } catch {
            const match = rawText.match(/\{[\s\S]*"texts"[\s\S]*\}/);
            if (match) {
                parsed = JSON.parse(match[0]);
            } else {
                throw new Error('Failed to parse JSON from response:\n' + rawText.substring(0, 300));
            }
        }

        renderAdCards(parsed.texts || [], meta);
        chrome.storage.local.set({ ad_results: lastResults });
    } catch (err) {
        let msg = err.message;
        if (msg.includes('Failed to fetch') || msg.includes('NetworkError')) {
            msg = 'Сеть недоступна. Убедитесь, что вы в корпоративной сети.';
        }
        adResults.innerHTML = '<div class="ad-error">' + escapeHtml(msg) + '</div>';
    } finally {
        busy = false;
        generateBtn.disabled = false;
        generateBtn.classList.remove('loading');
    }
}

// ========================
// Render result cards
// ========================

function renderAdCards(texts, meta) {
    lastResults = { texts: JSON.parse(JSON.stringify(texts)), meta };
    adResults.innerHTML = '';

    if (!texts.length) {
        adResults.innerHTML = '<div class="ad-error">Пустой ответ от модели</div>';
        return;
    }

    texts.forEach((item, index) => {
        const platform = PLATFORMS[item.system];
        const group = PLATFORM_GROUP[item.system] || '';
        const card = document.createElement('div');
        card.className = 'ad-card ad-card-enter';
        card.style.animationDelay = (index * 80) + 'ms';
        card.dataset.index = index;
        if (group) card.dataset.platform = group;

        let html = '<div class="ad-card-header">';
        html += '<span class="ad-card-platform">' + escapeHtml(platform?.label || item.system) + '</span>';
        html += '<button class="ad-card-copy">' + SVG_CLIPBOARD + ' Копировать</button>';
        html += '</div>';

        if (item.headline) html += renderField('Заголовок', item.headline, platform?.headline, 'headline');
        if (item.subheadline) html += renderField('Подзаголовок', item.subheadline, platform?.subheadline, 'subheadline');
        if (item.text) html += renderField('Текст', item.text, platform?.text, 'text');
        if (meta) html += '<div class="ad-meta">' + escapeHtml(meta) + '</div>';

        card.innerHTML = html;

        // Copy reads from DOM (edited text)
        const copyBtn = card.querySelector('.ad-card-copy');
        copyBtn.addEventListener('click', () => {
            const parts = [];
            card.querySelectorAll('.ad-field-text').forEach(el => {
                const t = el.textContent.trim();
                if (t) parts.push(t);
            });
            navigator.clipboard.writeText(parts.join('\n\n')).then(() => {
                copyBtn.innerHTML = SVG_CHECK + ' Скопировано';
                copyBtn.classList.add('copied');
                setTimeout(() => {
                    copyBtn.innerHTML = SVG_CLIPBOARD + ' Копировать';
                    copyBtn.classList.remove('copied');
                }, 1500);
            });
        });

        // Live edit: update char count + save
        card.querySelectorAll('.ad-field-text').forEach(el => {
            el.addEventListener('input', () => {
                if (el.dataset.max) updateFieldCount(el);
                saveEditedResults();
            });
        });

        adResults.appendChild(card);
    });
}

function renderField(label, value, limit, field) {
    const len = value.length;
    let html = '<div class="ad-field">';
    html += '<div class="ad-field-label">' + escapeHtml(label) + '</div>';
    html += '<div class="ad-field-text" contenteditable="true" data-field="' + field + '"' + (limit ? ' data-max="' + limit[1] + '"' : '') + '>' + escapeHtml(value) + '</div>';
    if (limit) {
        const max = limit[1];
        const pct = Math.min((len / max) * 100, 100);
        const cls = len > max ? 'over' : len > max * 0.9 ? 'warn' : 'ok';
        html += '<div class="ad-char-count ' + cls + '">' + len + ' / ' + max + '</div>';
        html += '<div class="ad-char-bar"><div class="ad-char-bar-fill ' + cls + '" style="width:' + pct.toFixed(1) + '%"></div></div>';
    }
    html += '</div>';
    return html;
}

function updateFieldCount(el) {
    const max = parseInt(el.dataset.max);
    const len = el.textContent.length;
    const pct = Math.min((len / max) * 100, 100);
    const cls = len > max ? 'over' : len > max * 0.9 ? 'warn' : 'ok';
    const field = el.closest('.ad-field');
    const countEl = field.querySelector('.ad-char-count');
    const barFill = field.querySelector('.ad-char-bar-fill');
    if (countEl) {
        countEl.textContent = len + ' / ' + max;
        countEl.className = 'ad-char-count ' + cls;
    }
    if (barFill) {
        barFill.style.width = pct.toFixed(1) + '%';
        barFill.className = 'ad-char-bar-fill ' + cls;
    }
}

function saveEditedResults() {
    if (!lastResults) return;
    adResults.querySelectorAll('.ad-card[data-index]').forEach(card => {
        const i = parseInt(card.dataset.index);
        if (!lastResults.texts[i]) return;
        card.querySelectorAll('.ad-field-text[data-field]').forEach(el => {
            lastResults.texts[i][el.dataset.field] = el.textContent;
        });
    });
    chrome.storage.local.set({ ad_results: lastResults });
}

function escapeHtml(str) {
    const d = document.createElement('div');
    d.textContent = str;
    return d.innerHTML;
}
